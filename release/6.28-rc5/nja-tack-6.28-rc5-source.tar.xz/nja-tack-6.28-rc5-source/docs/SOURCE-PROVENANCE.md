# Source provenance and distribution

NJA TACK is a local Felucca-derived development snapshot, not a clean upstream tag.
Upstream project: <https://github.com/hugelton/Felucca> by Leo Kuroshita / Hügelton
Instruments. See CREDITS.md and LICENSING.md for retained third-party attribution.
NJA branding does not claim authorship of upstream engines, assets or firmware.

RC5 was copied from the isolated RC4 UI review, itself copied from frozen RC3; the working/live tree, RC3 and historical 6.27
were not edited. The RC5 app diff is confined to LOOP drawing and its boot version
label. RC4 (FM-1_992) remains unchanged as a superseded local-only build.
The build map adds FM-1_65262805 for RC5; host renderer/tests and clean documentation
are added. Python companion defaults and two legacy test paths become repo-relative
for portability/privacy. No audio/recording/control feature was introduced. A separate minimal app
persistence JEDEC gate correction accepts both known 1 MiB chip IDs; the unchanged
loader already has no old-chip-only filter. Physical writes on both variants
remain untested for this exact candidate.

The source archive contains firmware, populated MIT engines, assets, fonts,
samples with attribution, tools, web source and host tests. It excludes private
working copies, .git data, credentials, caches, logs, SDK/toolchain installations,
old patch scratch and stale historical guides. Source files are checksummed in
SOURCE-MANIFEST.sha256. Generated build data is recreated by the documented tools;
compiled USER phrases matching the reviewed candidate remain in source.

The actual `.fwsc` contains three unmodified Apache-2.0 JieLi SDK files as described
in LICENSING.md. The SDK/toolchain are prerequisites rather than copied private
installations. Keep the full source archive and licence/attribution files next to
the matching firmware whenever redistributing. Generic forge ZIP archives may
omit engines; inspect before offering one as corresponding source.

This archive is prepared for a proper repository/cloud handoff, not evidence
that a remote repository, public release or Hub listing already exists. No secret,
private path, unpublished credential or unsupported endorsement belongs in public
release text. All publication links must be inserted only after verification.
