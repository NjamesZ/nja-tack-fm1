# Proposed public project copy — draft, not posted

## Repository description

NJA TACK: free GPL-3.0 FM-1 firmware for harmony moves and scale-aware MIDI recording,
with preserved close-onset chords. Felucca-derived; experimental RC5.

## Short introduction

Meet NJA TACK for the M-VAVE FM-1: choose harmony moves on the hardware, play
melodies and chords over MIDI, then decide when to LOOP or APPLY. Close-onset
chords keep their voicing; melody follows the scale. Free software, full source,
upstream credits intact.

## Release / Hub description

6.28-rc5 (FM-1_65262805) is a focused LOOP-screen readability candidate on top of RC3's
recording corrections, with a currently free long identity and app acceptance of
both known flash-chip IDs. Physical compatibility tests remain pending. The actual host-rendered screen and host regression logs
are included. RC3 received positive feedback in one controlled user trial;
RC5 is not yet flashed or hardware-qualified. Four recorded voices; 80 ms onset
policy; new performance metadata RAM-only; export remains harmony-only.

Before publishing: add the verified project/source/download URLs and checksums;
confirm the target listing's requirements; attach all licences and complete
matching source; keep experimental status visible. Do not use invented links,
claim an official partnership, copy another listing or imply comprehensive audio
validation. Prepared text only: no post, upload or listing has been made.
