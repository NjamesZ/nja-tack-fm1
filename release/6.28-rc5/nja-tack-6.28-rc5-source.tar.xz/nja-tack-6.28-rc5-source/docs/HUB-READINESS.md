# Firmware Hub publication checklist — not a listing claim

Sources checked 10 November 2026 HKT:
- https://thefirmwarehub.com/submit/
- https://thefirmwarehub.com/fmhub.md
- https://thefirmwarehub.com/kb/#loader
- https://thefirmwarehub.com/tools/rescue/

## Prepared locally

- GPL-3.0-only root LICENSE, populated engine sources and component licence texts.
- Root fmhub.json: plain factual description, no advertising; NJA project story
  stays in README. Real 240×240 framebuffer PNG under 300 KB.
- RC5 running identity FM-1_65262805: format is FM-1_ plus 3–8 digits; 13 characters
  fits the package’s 20-character marker and protocol’s 27-byte identity payload.
  The submit checker’s exact-product and non-generic anchored-range checks against
  the live 172-entry catalogue found no owner/matching reserved range. This does
  not reserve the prefix or guarantee future availability; recheck before publishing.
- RC3/FM-1_991 and RC4/FM-1_992 overlap Dinghy’s FM-1_99[0-8] range. They remain
  local historical builds only; their prior hardware trial is not RC5 qualification.
- Both app chip IDs accepted: Puya P25Q80 0x856014 and UC25HQ80 0xB36014. Actual
  boot-gate host test covers both and rejects unknown IDs. Existing loader performs
  plain NOR operations and has no JEDEC whitelist; no claim of physical write tests.
- The package embeds the existing Felucca update loader. Keeping its familiar
  ota-FM-1_900 loader identity does not change RC5’s unique running-app identity.

## Pending — every item is a release blocker, not a checked test

- [ ] Public GitHub repository: complete browsable source at the exact release tag,
      root LICENSE and matching populated engines; a source attachment alone is insufficient.
- [ ] GitHub release with the exact checked .fwsc attached and complete matching source.
- [ ] Root fmhub.json on the default branch; online “Check your file” after push.
- [ ] Recheck identity availability against the live public checker at publication time.
- [ ] Install the exact release file from official V15 on a real FM-1; boot and identity.
- [ ] Install the same file from another custom firmware; boot and Hub Connect naming.
- [ ] Leave RC5 by installing another firmware using its update loader; verify next identity.
- [ ] Verify USB MIDI enumeration/port (normally Felucca), and FM-1_65262805 response.
- [ ] Separately approved controlled interrupted-Writing/recovery/resume test with backup;
      read the Hub rescue instructions first. No unplug/recovery test was done here.
- [ ] Real saves/updates on both flash-chip variants, or clear supported-hardware evidence.
- [ ] Record project/sample incompatibilities and RAM-only caveats in README.
- [ ] Separately approved musical bench checklist in INSTALL.md on the exact file.

Do not tick these using emulator output, packet counts, RC3 praise or a new build.
No new flashing approval is inherited from RC3’s one-time approval.

## Submission only after readiness

First listing is an email to zven@thefirmwarehub.com with project/maker name,
public repository, unique identity, licence and truthful completed hardware tests.
The parent must prepare that email through its review/approval card; no email was
sent by this executor. Do not claim leaving/installing works before testing it.
Later GitHub releases may be ingested automatically, including prereleases.

VIBE conversion is a separate request, not this listing path. No plugin/browser
conversion compatibility has been established for TACK. Never imply otherwise.
