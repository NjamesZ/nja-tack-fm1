# NJA TACK for M-Wave FM-1

**Free, open-source firmware under GPL-3.0-only. Harmony moves, played MIDI, one small instrument.**

NJA TACK is an independent, Felucca-derived firmware project for the **M-VAVE FM-1**
(often written “M-Wave”). NJA is the project branding; upstream authorship and
third-party licences remain intact. No affiliation with or endorsement by M-VAVE,
Hügelton Instruments or a firmware listing service is implied.

## Current candidate: 6.28-rc5 / FM-1_65262805

Experimental review candidate, **not a final hardware-qualified release**.
RC3 was installed in one controlled trial and received positive subjective user
feedback (“Love it”). RC5 includes LOOP display cleanup, release documentation, a unique long identity
and app acceptance of both known 1 MiB flash chips;
it has **not** been flashed or listened to on hardware. See [test status](docs/TESTING.md).
No Firmware Hub listing or public repository availability is claimed by this archive.

## What TACK does

- Four-slot harmony with six hardware harmony-move choices, styles and modes.
- Played-note recording from USB/TRS MIDI without turning keys 1–6 into a keyboard.
- Close-onset overlapping chords retain their performed absolute pitches;
  later/legato melody follows the selected scale and root.
- LOOP replays performed note timing; APPLY writes patterned four-slot harmony.
- In-RAM A/B and undo retain user-owned/literal slot metadata.
- The underlying Felucca sound engines, sounds, drums and effects remain credited
  in [CREDITS.md](CREDITS.md). Host simulation is not a sound-quality guarantee.

## Start here

1. Read [installation and recovery](docs/INSTALL.md); keep your known-good package.
2. Use [quick start](docs/QUICKSTART.md) after installing a separately approved build.
3. Read the [control guide](docs/CONTROLS.md) and [recording policy](docs/RECORDING.md).
4. For developers: [BUILDING.md](BUILDING.md), [test evidence](docs/TESTING.md),
   [source provenance](docs/SOURCE-PROVENANCE.md), [changelog](CHANGELOG.md).

![Actual host-rendered LOOP region](docs/images/loop-rc5-crop.png)

The image is a 240 × 218 crop of the actual 240 × 240 firmware framebuffer,
rendered by `tests/tack_ui_review.c` using the real drawing code and fonts.
It is not a mockup, device photo or audio test.

## Important limits

- The chord window is **80 ms from the earliest onset**, with actual overlap;
  it is not an indefinitely chained window. Legato notes outside it remain melody.
- **Four simultaneous recorded MIDI voices**, 32 raw notes, 16 combined
  classified/move events and 64 pending MIDI messages. Overflow rejects the
  whole capture as `REC FULL`; it does not silently trim a successful take.
- New raw timing, channel ownership and literal-voicing metadata are **RAM-only**.
  Legacy project/phrase export does not preserve a complete performed MIDI clip.
- Shared eight-voice synthesis budget: other parts, stealing, scheduling and
  UI load still need wider hardware measurements. No sample-exact timing claim.
- Don't route MIDI output back into input. Arbitrary external loopback is input;
  internal LOOP playback is not fed back into the recorder.
- Known inherited host-test failures and unresolved sanitizer timeouts remain.

## Firmware Hub prerequisites

The prior short RC3/RC4 IDs overlap another project’s declared Hub range. They
remain historical local-only trial/review builds, not public release identities.
RC5 uses FM-1_65262805, currently free under the public checker’s live-catalog
rules; this is not a future reservation. The root `fmhub.json` and real screen
image are prepared. Public tagged source/release and exact-file install/leave
hardware tests are **still pending**; see [Hub readiness](docs/HUB-READINESS.md).
We do not claim cross-firmware project/sample compatibility; back up before any
change. No VIBE, plugin or conversion compatibility is claimed.

## Free software and complete source

There is no purchase or paid tier in this project. You may use, study, modify and
redistribute it under the applicable licences. The main application is
**GPL-3.0-only**; bundled components retain MIT, Apache-2.0, OFL and CC0 terms.
See [LICENSE](LICENSE), [LICENSING.md](LICENSING.md), [LICENSES/](LICENSES/) and
[CREDITS.md](CREDITS.md). Free does not mean warranty or guaranteed compatibility.

Distribute the matching full source archive and licence files with binary
releases, including the populated `firmware/engines/` directory. A source-only
forge ZIP is not a substitute if it omits engines. Toolchain and SDK prerequisites
are documented rather than bundled. Firmware installation is at your own risk.
